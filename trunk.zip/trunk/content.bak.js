function clickHandler() {
    alert('click handled');
}

(function() {
    alert('alert');
})();